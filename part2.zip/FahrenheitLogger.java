public class FahrenheitLogger {
    private double theTemperature;

    public double getTheTemperature() {
        return theTemperature;
    }

    public void setTheTemperature(double theTemperature) {
        this.theTemperature = theTemperature;
    }
}

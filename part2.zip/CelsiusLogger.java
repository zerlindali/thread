public abstract class CelsiusLogger {
  public abstract void setTemperature(double aCelsiusTemp);
  public abstract double getTemperature();
}

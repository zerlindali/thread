public abstract class WeatherObserver {
  public abstract void update();
}
